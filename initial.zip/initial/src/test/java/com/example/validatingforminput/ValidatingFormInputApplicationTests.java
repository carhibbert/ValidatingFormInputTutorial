package com.example.validatingforminput;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ValidatingFormInputApplicationTests {

	@Test
	void contextLoads() {
	}

}
